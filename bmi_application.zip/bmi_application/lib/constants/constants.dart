import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

final Color greencolor = HexColor('#64DD17');
final Color redcolor = HexColor('#FF1744');
